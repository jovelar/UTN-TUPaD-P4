from gasto import Impuesto, Ciudad, Provincia, Pais
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def ciudad(n, hab, gasto, *montos):
    c = Ciudad(n, hab, gasto)
    for m in montos: c.agregar_impuesto(Impuesto("imp", m))
    return c
def main():
    print("=== Ejercicio 3: Control de gasto publico ===\n")
    gd = ciudad("MetroA", 150_000, 1000, 100,100,100,100,100)
    check("5 impuestos completos", gd.impuestos_completos)
    check("total_recaudado = 500", gd.total_recaudado == 500)
    check("controlada (>100k)", gd.controlada)
    check("en_deficit (1000 > 500)", gd.en_deficit)
    go = ciudad("MetroB", 200_000, 1000, 300,300,300,200,100)
    check("Grande sin deficit", not go.en_deficit)
    ch = ciudad("Pueblo", 50_000, 800, 100,100,100,100,100)
    check("Chica NO controlada", not ch.controlada)
    check("Chica en_deficit a nivel ciudad", ch.en_deficit)
    try:
        gd.agregar_impuesto(Impuesto("imp6", 1)); r = False
    except ValueError: r = True
    check("No se puede un 6to impuesto", r)
    arg = Pais("Argentina"); prov = Provincia("ProvX")
    prov.agregar_ciudad(gd); prov.agregar_ciudad(go); prov.agregar_ciudad(ch)
    arg.agregar_provincia(prov)
    defi = arg.ciudades_deficitarias()
    check("Deficitarias incluye la grande", gd in defi)
    check("Deficitarias NO incluye la chica (auditoria)", ch not in defi)
    check("Total reportadas = 1", len(defi) == 1)
    check("Provincia NO en riesgo (1 de 2)", not prov.mitad_ciudades_en_deficit)
    gd2 = ciudad("MetroC", 300_000, 999, 100,100,100,100,100)
    prov.agregar_ciudad(gd2)
    check("Provincia EN riesgo (2 de 3)", prov.mitad_ciudades_en_deficit)
    check("provincias_en_riesgo la incluye", prov in arg.provincias_en_riesgo())
    print(f"\n=== Resultado Ej.3: {_o}/{_c} verificaciones OK ===")
main()
