"""Ej.3 — Control de gasto público. No todo se dibuja; derivados; corrección de auditoría."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class Impuesto:
    tipo: str
    monto_recaudado: float


class Ciudad:
    """Composición 1 *-- 5 Impuesto. Derivados: total_recaudado, controlada, en_deficit."""
    UMBRAL_CONTROL = 100_000
    _CANT_IMPUESTOS = 5

    def __init__(self, nombre: str, habitantes: int, gasto_mantenimiento: float) -> None:
        self.nombre = nombre
        self.habitantes = habitantes
        self.gasto_mantenimiento = gasto_mantenimiento
        self._impuestos: list[Impuesto] = []

    def agregar_impuesto(self, imp: Impuesto) -> None:
        if len(self._impuestos) >= self._CANT_IMPUESTOS:
            raise ValueError("Una ciudad recauda exactamente 5 tipos de impuesto")
        self._impuestos.append(imp)

    @property
    def impuestos_completos(self) -> bool:
        return len(self._impuestos) == self._CANT_IMPUESTOS

    @property
    def total_recaudado(self) -> float:              # derivado
        return sum(i.monto_recaudado for i in self._impuestos)

    @property
    def controlada(self) -> bool:                    # derivado
        return self.habitantes > self.UMBRAL_CONTROL

    @property
    def en_deficit(self) -> bool:                    # derivado
        return self.gasto_mantenimiento > self.total_recaudado


class Provincia:
    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self._ciudades: list[Ciudad] = []

    def agregar_ciudad(self, c: Ciudad) -> None:
        self._ciudades.append(c)

    @property
    def ciudades(self) -> list[Ciudad]:
        return list(self._ciudades)

    @property
    def mitad_ciudades_en_deficit(self) -> bool:
        """Derivado sobre el universo de ciudades CONTROLADAS (corrección de auditoría)."""
        controladas = [c for c in self._ciudades if c.controlada]
        if not controladas:
            return False
        en_def = sum(1 for c in controladas if c.en_deficit)
        return en_def * 2 > len(controladas)


class Pais:
    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self._provincias: list[Provincia] = []

    def agregar_provincia(self, p: Provincia) -> None:
        self._provincias.append(p)

    @property
    def provincias(self) -> list[Provincia]:
        return list(self._provincias)

    def ciudades_deficitarias(self) -> list[Ciudad]:
        """Corrección de auditoría: solo ciudades CONTROLADAS en déficit."""
        return [c for p in self._provincias for c in p.ciudades
                if c.controlada and c.en_deficit]

    def provincias_en_riesgo(self) -> list[Provincia]:
        return [p for p in self._provincias if p.mitad_ciudades_en_deficit]
