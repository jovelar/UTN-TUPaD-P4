// ACTIVIDAD 5 - El experimento controlado (Figura 11 del cierre)
//
// Esta clase y su version Python (python/poligono.py) representan el
// MISMO diagrama UML. Es el ejemplo que cierra toda la unidad: lo unico
// que cambio entre las dos versiones fueron los MECANISMOS (modificadores,
// ceremonias, obligatoriedad de la herencia) -no el diseno.

import java.util.ArrayList;
import java.util.List;

public abstract class Poligono extends Figura {
    private final List<Lado> lados = new ArrayList<>();

    public int nroLados() {
        return lados.size();
    }
}
