"""
ACTIVIDAD 5 - Checklist de desintoxicacion: un ejemplo minimo por cada
uno de los 7 java-ismos, INCORRECTO vs CORRECTO. Sirve como referencia
rapida de code review.
"""

from dataclasses import dataclass
from typing import Protocol


# 1) get_x() / set_x() innecesario -> atributo publico o @property
class Punto_Incorrecto:
    def __init__(self, x: int) -> None:
        self._x = x

    def get_x(self) -> int:          # ruido: no hay logica adentro
        return self._x


class Punto_Correcto:
    def __init__(self, x: int) -> None:
        self.x = x                    # atributo publico, directo


# 2) __doble_guion creyendo que es private -> _simple es la convencion
class Cuenta_Incorrecta:
    def __init__(self) -> None:
        self.__saldo = 0              # mangling, no privacidad real


class Cuenta_Correcta:
    def __init__(self) -> None:
        self._saldo = 0               # convencion clara y suficiente


# 3 y 4) Herencia/interfaz solo para tener tipo comun -> duck typing / Protocol
class Dibujable(Protocol):
    def dibujar(self) -> None: ...


# 5) __init__ que solo asigna campos -> @dataclass
class Lado_Incorrecto:
    def __init__(self, longitud: float, color: str) -> None:
        self.longitud = longitud
        self.color = color


@dataclass
class Lado_Correcto:
    longitud: float
    color: str


# 6) for + append + acumulador traduciendo un stream -> comprehension
def cuadrados_incorrecto(xs: list[int]) -> list[int]:
    resultado = []
    for x in xs:
        resultado.append(x * x)
    return resultado


def cuadrados_correcto(xs: list[int]) -> list[int]:
    return [x * x for x in xs]


# 7) Confiar en type hints sin mypy -> correr mypy en CI
def agregar_lado_sin_red(lado) -> None:  # sin verificacion real
    pass
