"""
ACTIVIDAD 5 - El experimento controlado (Figura 11 del cierre)

Comparar con java/Poligono.java: mismo diagrama UML, mismo diseno.
Lo que cambio es lenguaje (private/final -> convencion + property;
metodo nroLados() -> @property nro_lados). Lo que quedo IDENTICO es la
jerarquia, la composicion y el hecho de que el valor es un atributo
DERIVADO (se calcula, no se almacena).

Conclusion de toda la unidad:
    Lo que cambia es lenguaje. Lo que queda es diseno.
"""

from abc import ABC


class Figura(ABC):
    pass


class Poligono(Figura, ABC):
    def __init__(self) -> None:
        self._lados: list = []

    @property
    def nro_lados(self) -> int:
        return len(self._lados)
