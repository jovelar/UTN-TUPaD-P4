# Actividad 5 — Checklist de desintoxicacion y el cierre

## java/
- Poligono.java — mitad del experimento controlado (Figura 11)

## python/
- poligono.py — la otra mitad: mismo diagrama UML, mismo diseno
- checklist_ejemplos.py — un ejemplo incorrecto/correcto por cada uno de los 7 java-ismos
