"""
ACTIVIDAD 4 - Duck typing: polimorfismo sin superclase comun

En Java, para meter objetos distintos en una lista y llamarles el mismo
metodo, el compilador EXIGE un tipo comun (una superclase o interfaz
compartida). En Python no hace falta: si el objeto tiene el metodo,
alcanza. Estas tres clases pueden no tener absolutamente nada en comun.

OJO: esto NO significa que la herencia "sobre" en general -ver
ejemplo en herencia_multiple.py y las notas en protocol_dibujable.py.
"""


class Triangulo:
    def calcular_area(self) -> float:
        return 12.0


class Circulo:
    def calcular_area(self) -> float:
        return 78.5


class Rectangulo:
    def calcular_area(self) -> float:
        return 20.0


if __name__ == "__main__":
    # Sin superclase comun: si tiene calcular_area(), sirve
    for f in [Triangulo(), Circulo(), Rectangulo()]:
        print(f.calcular_area())
