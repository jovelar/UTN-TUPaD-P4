"""
ACTIVIDAD 4 - Dos modos de fallo: AttributeError vs TypeError

Con duck typing puro, el olvido de un metodo se descubre al LLAMARLO
-quizas en produccion. Con una ABC (@abstractmethod), se descubre al
CONSTRUIR el objeto, con un TypeError que nombra exactamente lo que
falta. Esa distancia mas corta entre error y causa es una razon de
diseno legitima para elegir una ABC.
"""

from abc import ABC, abstractmethod


# --- Duck typing puro: el error espera hasta la llamada ---
class PentagonoSinABC:            # olvidamos calcular_area()
    pass


# --- Con ABC: el error no espera ---
class Poligono(ABC):
    @abstractmethod
    def lados_esperados(self) -> int: ...


class PentagonoSinMetodo(Poligono):  # olvidamos lados_esperados()
    pass


if __name__ == "__main__":
    print("--- Duck typing puro ---")
    f = PentagonoSinABC()          # construye sin quejarse
    try:
        f.calcular_area()          # explota aca, quizas mucho despues
    except AttributeError as e:
        print("AttributeError (tarde):", e)

    print("--- Con ABC ---")
    try:
        f2 = PentagonoSinMetodo()  # explota AL CONSTRUIR
    except TypeError as e:
        print("TypeError (temprano):", e)
