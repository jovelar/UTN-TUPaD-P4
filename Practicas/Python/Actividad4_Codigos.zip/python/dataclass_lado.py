"""
ACTIVIDAD 4 - dataclass: boilerplate en tres lineas

@dataclass genera automaticamente __init__, __eq__ y __repr__ a partir
de los campos declarados. En Java, este mismo codigo lo suele generar
el IDE, pero ese codigo generado VIVE como texto en el archivo -si se
agrega un campo y no se regenera, el equals queda desincronizado en
silencio. La dataclass DERIVA el comportamiento de la declaracion de
campos: nunca se puede desincronizar.

frozen=True da inmutabilidad real -algo que "final" en Java no logra
para el objeto completo (final protege campo por campo la referencia,
no el estado interno).
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Lado:
    longitud: float
    color: str = "negro"


if __name__ == "__main__":
    l1 = Lado(3.0)
    l2 = Lado(3.0)

    print("l1 == l2 ->", l1 == l2)   # True, sin escribir equals()
    print("repr(l1) ->", l1)          # Lado(longitud=3.0, color='negro')

    try:
        l1.longitud = 10.0            # FrozenInstanceError
    except Exception as e:
        print("Error esperado (frozen):", type(e).__name__)
