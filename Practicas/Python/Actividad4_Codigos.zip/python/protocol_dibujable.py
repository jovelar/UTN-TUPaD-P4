"""
ACTIVIDAD 4 - Protocol: el contrato SIN el acoplamiento

Comparar con java/Dibujable.java: en Java, la clase DECLARA que
implementa la interfaz (conoce el contrato). Con Protocol, la clase NO
SE ENTERA de que el protocolo existe -cumple con tener el metodo, y el
protocolo la verifica desde AFUERA (mypy chequea la firma).

Esto permite tipar codigo de terceros sin tocarlo: si una libreria
externa da una clase con dibujar() pero sin heredar de nada propio,
Python la acepta retroactivamente. En Java, eso exige un adaptador.
"""

from typing import Protocol


class Dibujable(Protocol):        # nadie hereda de esto
    def dibujar(self) -> None: ...


class Triangulo:                  # NO declara nada, no conoce a Dibujable
    def dibujar(self) -> None:
        print("Dibujando un triangulo (sin heredar de Dibujable)")


def render(x: Dibujable) -> None:  # mypy verifica que x tenga dibujar()
    x.dibujar()


if __name__ == "__main__":
    render(Triangulo())  # funciona: Triangulo "cumple" el Protocol sin saberlo
