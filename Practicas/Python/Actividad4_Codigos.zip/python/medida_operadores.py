"""
ACTIVIDAD 4 - Sobrecarga de operadores: el dominio se escribe como se dice

__add__ es un metodo "magico" (dunder) que Python llama automaticamente
cuando se usa el operador + entre dos instancias. Java NO tiene
sobrecarga de operadores: para sumar dos objetos del dominio hay que
escribir explicitamente a.sumar(b).

Devuelve una instancia NUEVA (no modifica self) porque la clase es
frozen (inmutable) y porque es lo correcto para un objeto-valor: dos
medidas se suman como se suman dos numeros, produciendo un tercero.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Medida:
    valor: float
    unidad: str

    def __add__(self, otra: "Medida") -> "Medida":
        if self.unidad != otra.unidad:
            raise ValueError("unidades incompatibles")
        return Medida(self.valor + otra.valor, self.unidad)


if __name__ == "__main__":
    print(Medida(3, "m") + Medida(4, "m"))   # Medida(valor=7, unidad='m')

    try:
        Medida(3, "m") + Medida(4, "kg")
    except ValueError as e:
        print("Error esperado:", e)
