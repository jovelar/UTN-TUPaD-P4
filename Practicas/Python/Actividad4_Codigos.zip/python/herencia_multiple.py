"""
ACTIVIDAD 4 - Herencia multiple real

Java no permite heredar de mas de una clase (solo interfaces) -ver
java/Empleado.java, resuelto con composicion. Python SI permite heredar
de varias clases a la vez, resuelto con el algoritmo MRO (C3).

CUIDADO: que Python lo permita no lo vuelve la mejor respuesta al
overlapping de roles. Si los roles se adquieren y se pierden en tiempo
de ejecucion, la composicion (como en Empleado.java) sigue siendo el
mejor modelo, porque la herencia es ESTATICA (fijada al definir la
clase). Este ejemplo muestra que Python puede hacerlo, no que deba.
"""


class RolDocente:
    def dar_clase(self) -> str:
        return "Dando clase"


class RolInvestigador:
    def investigar(self) -> str:
        return "Investigando"


class RolAdmin:
    def administrar(self) -> str:
        return "Administrando"


class Empleado(RolDocente, RolInvestigador, RolAdmin):
    pass


if __name__ == "__main__":
    e = Empleado()
    print(e.dar_clase())
    print(e.investigar())
    print(e.administrar())
    print("MRO:", [c.__name__ for c in Empleado.__mro__])
