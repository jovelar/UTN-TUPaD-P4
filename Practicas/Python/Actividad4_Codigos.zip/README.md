# Actividad 4 — Duck typing, Protocol y los regalos de Python

## java/
- Dibujable.java / Triangulo.java — interfaz clasica (contraparte de Protocol)
- Empleado.java — overlapping de roles resuelto por composicion

## python/
- duck_typing.py — polimorfismo sin superclase comun
- dos_modos_de_fallo.py — AttributeError (tarde) vs TypeError (temprano, con ABC)
- protocol_dibujable.py — el contrato sin el acoplamiento
- dataclass_lado.py — boilerplate en tres lineas
- herencia_multiple.py — MRO real (y por que composicion sigue siendo mejor aca)
- medida_operadores.py — sobrecarga de operadores (__add__)
