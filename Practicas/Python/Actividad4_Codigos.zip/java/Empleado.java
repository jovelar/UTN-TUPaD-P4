// ACTIVIDAD 4 - Overlapping de roles, resuelto por COMPOSICION en Java
//
// Java no permite heredar de mas de una clase (solo de interfaces), asi
// que el overlapping de roles se resuelve con composicion: cada rol es
// un campo opcional (puede ser null) en vez de una superclase.
//
// Este es el MISMO criterio de diseno que se usa del lado Python en
// python/herencia_multiple.py -aunque Python SI permite heredar de
// varias clases, la composicion sigue siendo mejor aca porque los
// roles se adquieren y se pierden en tiempo de ejecucion.

public class Empleado {
    private RolDocente rolDocente;         // null si no tiene el rol
    private RolInvestigador rolInvestigador;
    private RolAdmin rolAdmin;

    public RolDocente comoDocente() {
        if (rolDocente == null) {
            rolDocente = new RolDocente();
        }
        return rolDocente;
    }
}

class RolDocente {}
class RolInvestigador {}
class RolAdmin {}
