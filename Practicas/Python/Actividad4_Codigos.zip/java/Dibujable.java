// ACTIVIDAD 4 - Interfaz Java (contraparte de Protocol en Python)
//
// En Java, la clase DECLARA que implementa la interfaz: la direccion de
// la dependencia va de la clase hacia el contrato. El que cumple el
// contrato tiene que CONOCER el contrato (escribir "implements").
// Comparar con python/protocol_dibujable.py, donde esa direccion se invierte.

public interface Dibujable {
    void dibujar();
}
