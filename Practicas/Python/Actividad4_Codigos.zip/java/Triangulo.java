// ACTIVIDAD 4 - Triangulo implementa Dibujable explicitamente
//
// Si una libreria externa te da una clase con dibujar() pero SIN
// "implements Dibujable", en Java no hay forma de modificarla para
// agregarle el implements -hay que escribir un adaptador.

public class Triangulo implements Dibujable {
    @Override
    public void dibujar() {
        System.out.println("Dibujando un triangulo");
    }

    public static void main(String[] args) {
        Dibujable d = new Triangulo();
        d.dibujar();
    }
}
