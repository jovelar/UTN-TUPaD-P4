from datetime import date
from museo import (PinturaDetalle, EsculturaDetalle, EnPrestamo, ColeccionPermanente,
                   Ubicacion, Artista, Origen, Coleccion, ObjetoArte, Exposicion)
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def main():
    print("=== Ejercicio 9: Museo ===\n")
    origen_esp = Origen("Espana", "Barroco", "s.XVII")
    velazquez = Artista("Velazquez", date(1599, 6, 6), date(1660, 8, 6),
                        "Espana", "Barroco", "Realismo", "Pintor de camara")
    meninas = ObjetoArte("001", "Las Meninas", "Oleo sobre lienzo", 1656)
    meninas.tipo_detalle = PinturaDetalle("Oleo", "Lienzo", "Barroco")
    meninas.pertenencia_detalle = ColeccionPermanente(date(1819, 1, 1), 0, Ubicacion.EXPOSICION)
    meninas.artista = velazquez; meninas.origen = origen_esp
    check("Objeto tiene detalle Pintura", isinstance(meninas.tipo_detalle, PinturaDetalle))
    check("Objeto tiene detalle Permanente", isinstance(meninas.pertenencia_detalle, ColeccionPermanente))
    check("Pintura Y Permanente COEXISTEN (ejes ortogonales)",
          isinstance(meninas.tipo_detalle, PinturaDetalle)
          and isinstance(meninas.pertenencia_detalle, ColeccionPermanente))
    check("Artista opcional (0..1)", meninas.artista is velazquez)
    check("Origen asignado (1)", meninas.origen is origen_esp)
    meninas.tipo_detalle = EsculturaDetalle("Marmol", 2.0, 500, "Barroco")
    check("Reasignar eje tipo reemplaza (ya no Pintura)", not isinstance(meninas.tipo_detalle, PinturaDetalle))
    check("Ahora eje tipo es Escultura", isinstance(meninas.tipo_detalle, EsculturaDetalle))
    check("Eje pertenencia NO se afecta (independencia)",
          isinstance(meninas.pertenencia_detalle, ColeccionPermanente))
    prado = Coleccion("Museo del Prado", "publico", "-", "Madrid", "91", "Dir")
    prestada = ObjetoArte("002", "Retrato X", "-", 1700)
    prestada.tipo_detalle = PinturaDetalle("Acuarela", "Papel", "Neoclasico")
    prestada.pertenencia_detalle = EnPrestamo(date.today(), date.today(), prado)
    prestada.origen = origen_esp
    check("Segundo objeto: Pintura + EnPrestamo",
          isinstance(prestada.tipo_detalle, PinturaDetalle)
          and isinstance(prestada.pertenencia_detalle, EnPrestamo))
    check("El prestamo conoce la coleccion", prestada.pertenencia_detalle.prestada_por is prado)
    muestra = Exposicion("Maestros", date.today(), date.today())
    muestra.exhibir(meninas); muestra.exhibir(prestada)
    check("Exposicion exhibe 2 objetos (N:M)", len(muestra.exhibe) == 2)
    print(f"\n=== Resultado Ej.9: {_o}/{_c} verificaciones OK ===")
main()
