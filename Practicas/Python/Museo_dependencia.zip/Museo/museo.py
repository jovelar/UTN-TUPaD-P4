"""Ej.9 — Museo. Generalización ortogonal: dos ejes de subtipos independientes."""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date
from enum import Enum


# ── Eje 1: TIPO (disjoint, complete) ──
class TipoDetalle(ABC):
    @abstractmethod
    def descripcion_tipo(self) -> str: ...


@dataclass(frozen=True)
class PinturaDetalle(TipoDetalle):
    tipo_pintura: str
    soporte: str
    estilo: str
    def descripcion_tipo(self) -> str:
        return f"Pintura({self.tipo_pintura}, {self.soporte}, {self.estilo})"


@dataclass(frozen=True)
class EsculturaDetalle(TipoDetalle):
    material: str
    altura: float
    peso: float
    estilo: str
    def descripcion_tipo(self) -> str:
        return f"Escultura({self.material}, {self.altura}m, {self.peso}kg)"


@dataclass(frozen=True)
class OtrosDetalle(TipoDetalle):
    def descripcion_tipo(self) -> str:
        return "Otros"


# ── Eje 2: PERTENENCIA (disjoint, complete) — INDEPENDIENTE del eje tipo ──
class PertenenciaDetalle(ABC):
    @abstractmethod
    def descripcion_pertenencia(self) -> str: ...


class EnPrestamo(PertenenciaDetalle):
    def __init__(self, fecha_recepcion: date, fecha_devolucion: date, prestada_por: "Coleccion") -> None:
        self.fecha_recepcion = fecha_recepcion
        self.fecha_devolucion = fecha_devolucion
        self.prestada_por = prestada_por
    def descripcion_pertenencia(self) -> str:
        return f"EnPrestamo (de {self.prestada_por.nombre})"


class Ubicacion(Enum):
    EXPOSICION = "exposicion"
    ALMACEN = "almacen"


class ColeccionPermanente(PertenenciaDetalle):
    def __init__(self, fecha_adquisicion: date, coste: float, ubicacion: Ubicacion) -> None:
        self.fecha_adquisicion = fecha_adquisicion
        self.coste = coste
        self.ubicacion = ubicacion
    def descripcion_pertenencia(self) -> str:
        return f"Permanente({self.ubicacion.name})"


@dataclass(frozen=True)
class Artista:
    nombre: str
    fecha_nacimiento: date
    fecha_defuncion: date | None
    pais_origen: str
    epoca: str
    estilo_principal: str
    descripcion: str


@dataclass(frozen=True)
class Origen:
    pais: str
    cultura: str
    epoca: str


@dataclass(frozen=True)
class Coleccion:
    nombre: str
    tipo: str
    descripcion: str
    direccion: str
    telefono: str
    contacto: str


class ObjetoArte:
    """GENERALIZACIÓN ORTOGONAL: dos ejes independientes (tipo × pertenencia)."""
    def __init__(self, nro_id: str, titulo: str, descripcion: str, anio: int | None) -> None:
        self.nro_id = nro_id
        self.titulo = titulo
        self.descripcion = descripcion
        self.anio_creacion = anio
        self.tipo_detalle: TipoDetalle | None = None            # eje 1
        self.pertenencia_detalle: PertenenciaDetalle | None = None  # eje 2 (independiente)
        self.artista: Artista | None = None                    # 0..1
        self.origen: Origen | None = None                      # 1


class Exposicion:
    def __init__(self, nombre: str, fecha_inicio: date, fecha_fin: date) -> None:
        self.nombre = nombre
        self.fecha_inicio = fecha_inicio
        self.fecha_fin = fecha_fin
        self._exhibe: set[ObjetoArte] = set()

    def exhibir(self, o: ObjetoArte) -> None:
        self._exhibe.add(o)

    @property
    def exhibe(self) -> set[ObjetoArte]:
        return set(self._exhibe)
