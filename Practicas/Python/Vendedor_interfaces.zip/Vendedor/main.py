from datetime import date
from cosmetica import Producto, Cliente, Reunion, Ticket, Representante, Vendedor, Lider
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def main():
    print("=== Ejercicio 11: Cosmetica Natural ===\n")
    reunion = Reunion(date(2026, 6, 1), date(2026, 7, 1), 10.0)
    vendedor = Vendedor("Vero", "d", "t", date(1990, 1, 1), "20-1", date(2024, 1, 1))
    lider = Lider("Laura", "d", "t", date(1985, 1, 1), "27-2", date(2020, 1, 1), date(2022, 6, 1))
    check("Vendedor es Representante", isinstance(vendedor, Representante))
    check("Lider es Representante", isinstance(lider, Representante))
    check("Lider agrega fecha_promocion", lider.fecha_promocion == date(2022, 6, 1))
    vendedor2 = Vendedor("Marcos", "d", "t", date(1992, 1, 1), "20-3", date(2025, 1, 1))
    lider.coordinar(vendedor); lider.coordinar(vendedor2)
    check("Lider coordina 2 vendedores", len(lider.equipo) == 2)
    cli_vero = Cliente("Ana", "d", "t", date(1995, 1, 1), date(2025, 3, 1))
    cli_laura = Cliente("Sofia", "d", "t", date(1993, 1, 1), date(2025, 4, 1))
    vendedor.agregar_cliente(cli_vero); lider.agregar_cliente(cli_laura)
    check("Cada representante tiene su cartera", cli_vero in vendedor.cartera)
    crema = Producto("Crema Facial", 5000)
    desde = date(2026, 6, 15)
    t1 = vendedor.registrar_venta(crema, desde, 5000)
    check("Ticket ternario liga representante+producto", t1.representante is vendedor and t1.producto is crema)
    check("Ticket nace SIN cliente (0..1)", not t1.venta_completada)
    t1.completar_venta(cli_vero)
    check("Venta completada con cliente de cartera propia", t1.cliente is cli_vero)
    t2 = vendedor.registrar_venta(crema, desde, 5000)
    try:
        t2.completar_venta(cli_laura); r = False
    except ValueError: r = True
    check("Rechaza cliente de OTRO representante (integridad)", r)
    check("Comision Vendedor = 10% de 10000 = 1000", abs(vendedor.calcular_comision(reunion) - 1000.0) < 1e-6)
    vendedor2.registrar_venta(crema, desde, 3000)
    check("Comision Marcos = 10% de 3000 = 300", abs(vendedor2.calcular_comision(reunion) - 300.0) < 1e-6)
    lider.registrar_venta(crema, desde, 8000)
    check("Comision Lider = propia 800 + equipo 1300 = 2100", abs(lider.calcular_comision(reunion) - 2100.0) < 1e-6)
    fuerza = [vendedor, vendedor2, lider]
    total = sum(r.calcular_comision(reunion) for r in fuerza)
    check("Despacho polimorfico (1000+300+2100=3400)", abs(total - 3400.0) < 1e-6)
    vendedor.registrar_venta(crema, date(2026, 5, 1), 9999)
    check("Ventas previas a reunion NO cuentan", abs(vendedor.calcular_comision(reunion) - 1000.0) < 1e-6)
    print(f"\n=== Resultado Ej.11: {_o}/{_c} verificaciones OK ===")
main()
