"""Ej.11 — Cosmética Natural. Herencia, clase asociación ternaria y comisión polimórfica."""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import date


@dataclass(frozen=True)
class Producto:
    nombre: str
    precio_venta_publico: float


@dataclass(frozen=True)
class Cliente:
    nombre: str
    direccion: str
    telefono: str
    fecha_nacimiento: date
    fecha_ingreso: date


class Reunion:
    def __init__(self, fecha_ultima: date, fecha_proxima: date, porcentaje: float) -> None:
        self.fecha_ultima = fecha_ultima
        self.fecha_proxima = fecha_proxima
        self.porcentaje_comision = porcentaje


class Ticket:
    """CLASE ASOCIACIÓN TERNARIA (Representante, Producto, Cliente 0..1). Cliente diferido."""
    def __init__(self, representante: "Representante", producto: Producto,
                 fecha: date, precio: float) -> None:
        self.representante = representante
        self.producto = producto
        self.fecha = fecha
        self.precio = precio
        self.cliente: Cliente | None = None       # 0..1 (venta final diferida)

    def completar_venta(self, cliente: Cliente) -> None:
        """Integridad: el cliente debe pertenecer a la cartera del mismo representante."""
        if cliente not in self.representante.cartera:
            raise ValueError("Integridad Ticket-Cliente: cliente de otro representante")
        self.cliente = cliente

    @property
    def venta_completada(self) -> bool:
        return self.cliente is not None


class Representante(ABC):
    """{disjoint, complete}: Vendedor / Lider. calcular_comision() DERIVADO y POLIMÓRFICO."""
    def __init__(self, nombre: str, direccion: str, telefono: str,
                 fecha_nac: date, cuit: str, fecha_incorp: date) -> None:
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono
        self.fecha_nacimiento = fecha_nac
        self.cuit_cuil = cuit
        self.fecha_incorporacion = fecha_incorp
        self._cartera: set[Cliente] = set()
        self._ventas: list[Ticket] = []

    def agregar_cliente(self, c: Cliente) -> None:
        self._cartera.add(c)

    @property
    def cartera(self) -> set[Cliente]:
        return set(self._cartera)

    def registrar_venta(self, p: Producto, fecha: date, precio: float) -> Ticket:
        t = Ticket(self, p, fecha, precio)
        self._ventas.append(t)
        return t

    @property
    def ventas(self) -> list[Ticket]:
        return list(self._ventas)

    def total_ventas_propias_desde(self, corte: date) -> float:
        return sum(t.precio for t in self._ventas if t.fecha > corte)

    @abstractmethod
    def calcular_comision(self, reunion: Reunion) -> float:
        """POLIMÓRFICO: cada subclase lo calcula distinto."""


class Vendedor(Representante):
    def calcular_comision(self, reunion: Reunion) -> float:
        ventas = self.total_ventas_propias_desde(reunion.fecha_ultima)
        return ventas * (reunion.porcentaje_comision / 100.0)


class Lider(Representante):
    """Agrega fecha_promocion. Coordina 1..* Vendedor. Comisión = propia + % del equipo."""
    def __init__(self, nombre, direccion, telefono, fecha_nac, cuit, fecha_incorp, promocion) -> None:
        super().__init__(nombre, direccion, telefono, fecha_nac, cuit, fecha_incorp)
        self.fecha_promocion = promocion
        self._equipo: list[Vendedor] = []

    def coordinar(self, v: Vendedor) -> None:
        self._equipo.append(v)

    @property
    def equipo(self) -> list[Vendedor]:
        return list(self._equipo)

    def calcular_comision(self, reunion: Reunion) -> float:
        pct = reunion.porcentaje_comision / 100.0
        propia = self.total_ventas_propias_desde(reunion.fecha_ultima) * pct
        equipo = sum(v.total_ventas_propias_desde(reunion.fecha_ultima) for v in self._equipo) * pct
        return propia + equipo               # ADEMÁS: ventas del equipo
