# Actividad 2 — La property y el encapsulamiento

## java/
- Poligono.java — atributo derivado como metodo (nroLados())
- Cuenta.java — el caso de "final": protege la referencia, no el contenido

## python/
- poligono.py — el mismo atributo derivado como @property
- lado.py — property con validacion en el setter
- visibilidad.py — los tres niveles reales de Python (publico, _protegido, __mangled)
- mangling_demo.py — para que sirve realmente el doble guion bajo
- final_lados.py — tres formas de acercarse al "final" de Java
