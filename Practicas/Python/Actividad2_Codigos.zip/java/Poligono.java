// ACTIVIDAD 2 - Poligono con atributo derivado (version Java)
//
// nroLados() es un METODO porque en Java no existe forma de que un valor
// calculado se lea con sintaxis de atributo. Todo cliente que necesite ese
// valor tiene que escribir poligono.nroLados() -con parentesis- aunque
// conceptualmente sea un dato, no una accion.
//
// El super() para "ladosEsperados()" es abstracto: cada subclase concreta
// (Triangulo, Cuadrado, etc.) esta OBLIGADA por el compilador a implementarlo.

import java.util.ArrayList;
import java.util.List;

public abstract class Poligono extends Figura {

    private final List<Lado> lados = new ArrayList<>();

    public void agregarLado(Lado lado) {
        lados.add(lado);
    }

    /** Atributo derivado: se calcula, no se almacena. */
    public int nroLados() {
        return lados.size();
    }

    /** Cada subclase concreta refina la cantidad exacta. */
    protected abstract int ladosEsperados();

    public boolean estructuraValida() {
        int esperados = ladosEsperados();
        if (esperados == -1) return nroLados() >= 3;
        return nroLados() == esperados;
    }
}
