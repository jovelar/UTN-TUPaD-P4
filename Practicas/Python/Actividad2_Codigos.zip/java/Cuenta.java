// ACTIVIDAD 2 - El caso del "final" en Java
//
// "private final List<Lado> lados" dice DOS cosas a la vez:
//   1) private -> nadie de afuera toca esta lista
//   2) final   -> esta REFERENCIA no se reasigna nunca
//
// OJO: final protege la referencia, NO el contenido. La linea marcada
// abajo COMPILA perfecto, aunque "lados" sea final -es una garantia
// mas debil de lo que parece.

import java.util.ArrayList;
import java.util.List;

public class Cuenta {

    private final List<String> movimientos = new ArrayList<>();

    public void registrar(String movimiento) {
        movimientos.add(movimiento); // compila OK: final protege la referencia, no esto
    }

    public static void main(String[] args) {
        Cuenta c = new Cuenta();
        c.registrar("deposito 100");
        c.registrar("extraccion 50");
        System.out.println(c.movimientos);

        // La siguiente linea SI rompe la compilacion (reasignacion de "final"):
        // c.movimientos = new ArrayList<>();
    }
}
