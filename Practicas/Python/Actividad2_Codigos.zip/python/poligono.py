"""
ACTIVIDAD 2 - Poligono con atributo derivado (version Python)

nro_lados es una @property: se LEE como un atributo (poligono.nro_lados,
sin parentesis) pero por dentro ejecuta una funcion que calcula el valor.
Esto es la traduccion sintactica exacta del atributo derivado "/nroLados"
del diagrama UML (la barra "/" significa: se calcula, no se almacena).

@abstractmethod obliga a las subclases concretas a implementar
lados_esperados(), igual que "protected abstract int ladosEsperados()"
en Java -pero SOLO si en algun punto de la herencia hay una clase ABC.
Si no hay ningun ABC en la cadena, el decorador se ignora en silencio.
"""

from abc import ABC, abstractmethod


class Lado:
    def __init__(self, longitud: float) -> None:
        self.longitud = longitud


class Figura(ABC):
    pass


class Poligono(Figura, ABC):
    def __init__(self) -> None:
        super().__init__()
        self._lados: list[Lado] = []

    def agregar_lado(self, lado: Lado) -> None:
        self._lados.append(lado)

    @property
    def nro_lados(self) -> int:          # derivado: se calcula
        return len(self._lados)

    @abstractmethod
    def lados_esperados(self) -> int:
        """Cada subclase concreta refina la cantidad exacta."""

    @property
    def estructura_valida(self) -> bool:
        esperados = self.lados_esperados()
        if esperados == -1:
            return self.nro_lados >= 3
        return self.nro_lados == esperados


class Triangulo(Poligono):
    def lados_esperados(self) -> int:
        return 3


if __name__ == "__main__":
    t = Triangulo()
    t.agregar_lado(Lado(3))
    t.agregar_lado(Lado(4))
    t.agregar_lado(Lado(5))

    # Se lee como atributo, aunque por dentro se ejecuta un metodo:
    print("nro_lados:", t.nro_lados)
    print("estructura_valida:", t.estructura_valida)
