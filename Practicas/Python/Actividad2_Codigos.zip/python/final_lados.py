"""
ACTIVIDAD 2 - El caso del "final" - tres aproximaciones en Python, de menos
a mas fuerte.

Recordar: el "final" de Java protege la REFERENCIA, no el contenido
(ver java/Cuenta.java). Es una garantia mas debil de lo que parece.
"""

from dataclasses import dataclass
from typing import Final


# 1) Documentar la intencion: mypy lo verifica, el runtime NO hace nada.
class Poligono1:
    def __init__(self) -> None:
        self._lados: Final[list] = []


# 2) Property de solo lectura que devuelve una COPIA: protege la
#    referencia Y evita que el cliente mute el contenido interno.
#    Es MAS fuerte que el "final" de Java.
class Poligono2:
    def __init__(self) -> None:
        self._lados: list = []

    @property
    def lados(self) -> list:
        return list(self._lados)  # copia defensiva: el cliente no muta el original


# 3) Inmutabilidad real: la unica de las tres que impide modificar
#    el objeto despues de construido.
@dataclass(frozen=True)
class Lado:
    longitud: float


if __name__ == "__main__":
    p2 = Poligono2()
    p2._lados.append(Lado(3.0))
    copia = p2.lados
    copia.append(Lado(99.0))  # muta la copia, no el original
    print("Lados internos (sin cambios):", p2._lados)
    print("Copia externa (con el agregado):", copia)

    lado = Lado(5.0)
    try:
        lado.longitud = 10.0  # dispara FrozenInstanceError
    except Exception as e:
        print("Error esperado (frozen):", type(e).__name__, "-", e)
