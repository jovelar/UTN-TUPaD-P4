"""
ACTIVIDAD 2 - La property con validacion (setter)

self.longitud = longitud dentro de __init__ NO asigna un atributo
directamente: como "longitud" es una property con setter, esta linea
en realidad LLAMA al setter de mas abajo. Por eso incluso la
CONSTRUCCION del objeto pasa por la validacion -no hay puerta trasera.

El punto clave: el codigo cliente (lado.longitud = 5.0) es EXACTAMENTE
igual antes y despues de agregar la validacion. En Java, agregar esta
misma regla hubiese obligado a cambiar todo el codigo cliente de
"lado.longitud = 5.0" a "lado.setLongitud(5.0)".
"""


class Lado:
    def __init__(self, longitud: float) -> None:
        self.longitud = longitud  # pasa por el setter de abajo

    @property
    def longitud(self) -> float:
        return self._longitud

    @longitud.setter
    def longitud(self, valor: float) -> None:
        if valor <= 0:
            raise ValueError("un lado debe medir mas que cero")
        self._longitud = valor


if __name__ == "__main__":
    lado = Lado(5.0)
    print("Longitud valida:", lado.longitud)

    lado.longitud = 8.0  # el cliente escribe lo mismo de siempre
    print("Longitud actualizada:", lado.longitud)

    try:
        lado.longitud = -1  # dispara la validacion
    except ValueError as e:
        print("Error esperado:", e)
