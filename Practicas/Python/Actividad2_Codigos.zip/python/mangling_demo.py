"""
ACTIVIDAD 2 - Para que existe realmente el doble guion bajo

El mangling NO fue disenado para dar privacidad: fue disenado para
evitar colisiones de nombres en jerarquias de herencia. Sin mangling,
la asignacion del hijo pisaria la del padre. Con mangling, ambos
atributos conviven porque Python los renombra por clase:
_Figura__cache y _Poligono__cache son atributos DISTINTOS.
"""


class Figura:
    def __init__(self) -> None:
        self.__cache = None   # se guarda internamente como _Figura__cache


class Poligono(Figura):
    def __init__(self) -> None:
        super().__init__()
        self.__cache = {}     # se guarda internamente como _Poligono__cache


if __name__ == "__main__":
    p = Poligono()
    print("Atributos reales del objeto:", vars(p))
    # {'_Figura__cache': None, '_Poligono__cache': {}}
    # Sin mangling, "_Poligono__cache" hubiese pisado a "_Figura__cache".
