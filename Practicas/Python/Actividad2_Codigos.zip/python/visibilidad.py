"""
ACTIVIDAD 2 - Los tres niveles de visibilidad en Python

Ninguno de los tres es el "private" de Java. No hay un equivalente
escondido ni un truco que lo reproduzca -simplemente no existe.

- self.saldo      -> publico. Igual a un campo public de Java.
- self._interno   -> "protected" por CONVENCION. El interprete no hace
                      nada especial; es un cartel de "no entres".
- self.__mangled  -> "name mangling". El interprete SI hace algo: lo
                      renombra automaticamente a _Cuenta__mangled.
                      Pero eso NO es privacidad: el nombre nuevo es
                      predecible y sigue siendo accesible desde afuera.
"""


class Cuenta:
    def __init__(self) -> None:
        self.saldo = 0          # publico
        self._interno = 0       # "protected" - convencion
        self.__mangled = 0      # name mangling


if __name__ == "__main__":
    c = Cuenta()

    c.saldo = 100                 # OK, es publico
    c._interno = 50               # "no deberias", pero funciona
    print("Nombre real del atributo mangled:", vars(c))

    # El doble guion bajo NO es una barrera, solo cambia el nombre:
    c._Cuenta__mangled = 999
    print("Acceso al atributo 'mangled' desde afuera:", c._Cuenta__mangled)
