"""Ej.6 — Parques nacionales. Herencia overlapping (roles) y clase asociación ternaria."""
from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import date


# ── Jerarquía de especies (disjoint/complete) ──
class Especie(ABC):
    def __init__(self, nombre_cientifico: str, nombre_vulgar: str) -> None:
        self.nombre_cientifico = nombre_cientifico
        self.nombre_vulgar = nombre_vulgar


class Vegetal(Especie):
    def __init__(self, nc: str, nv: str, tiene_floracion: bool, periodo: str) -> None:
        super().__init__(nc, nv)
        self.tiene_floracion = tiene_floracion
        self.periodo_floracion = periodo


class Animal(Especie):
    def __init__(self, nc: str, nv: str, periodo_celo: str) -> None:
        super().__init__(nc, nv)
        self.periodo_celo = periodo_celo
        self._se_alimenta_de: set[Especie] = set()

    def agregar_alimento(self, e: Especie) -> None:
        self._se_alimenta_de.add(e)

    @property
    def se_alimenta_de(self) -> set[Especie]:
        return set(self._se_alimenta_de)

    @abstractmethod
    def dieta(self) -> str: ...


class Herbivora(Animal):
    def dieta(self) -> str: return "Herbivora"


class Carnivora(Animal):
    def dieta(self) -> str: return "Carnivora"


class Omnivora(Animal):
    def dieta(self) -> str: return "Omnivora"


# ── Estructura del parque ──
@dataclass(frozen=True)
class ComunidadAutonoma:
    nombre: str
    organismo_responsable: str


@dataclass(frozen=True)
class Vehiculo:
    tipo: str
    matricula: str


@dataclass(frozen=True)
class Entrada:
    numero: int


@dataclass(frozen=True)
class Area:
    nombre: str
    km2: float


@dataclass(frozen=True)
class Proyecto:
    nombre: str
    presupuesto: float
    fecha_inicio: date
    fecha_fin: date


@dataclass(frozen=True)
class Visitante:
    dni: str
    nombre: str
    direccion: str
    profesion: str


# ── Roles del personal (overlapping por composición) ──
class RolCelador:
    def __init__(self) -> None:
        self.entrada_destino: Entrada | None = None

    def asignar_entrada(self, e: Entrada) -> None:
        self.entrada_destino = e


class RolGuarda:
    def __init__(self) -> None:
        self.area_asignada: Area | None = None
        self.vehiculo: Vehiculo | None = None

    def asignar(self, a: Area, v: Vehiculo) -> None:
        self.area_asignada = a
        self.vehiculo = v


class RolInvestigador:
    def __init__(self, titulacion: str) -> None:
        self.titulacion = titulacion


class Personal:
    """Overlapping por COMPOSICIÓN de roles opcionales (una persona puede ser varios a la vez)."""
    def __init__(self, dni: str, nombre: str, direccion: str, telefono: str,
                 sueldo: float, nss: str) -> None:
        self.dni = dni
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono
        self.sueldo = sueldo
        self.nro_seg_social = nss
        self.trabaja_en: Parque | None = None
        self._rol_celador: RolCelador | None = None
        self._rol_guarda: RolGuarda | None = None
        self._rol_investigador: RolInvestigador | None = None

    def asignar_trabajo(self, p: "Parque") -> None:
        self.trabaja_en = p

    def como_celador(self) -> RolCelador:
        if self._rol_celador is None:
            self._rol_celador = RolCelador()
        return self._rol_celador

    def como_guarda(self) -> RolGuarda:
        if self._rol_guarda is None:
            self._rol_guarda = RolGuarda()
        return self._rol_guarda

    def como_investigador(self, titulacion: str) -> RolInvestigador:
        if self._rol_investigador is None:
            self._rol_investigador = RolInvestigador(titulacion)
        return self._rol_investigador

    @property
    def es_celador(self) -> bool: return self._rol_celador is not None
    @property
    def es_guarda(self) -> bool: return self._rol_guarda is not None
    @property
    def es_investigador(self) -> bool: return self._rol_investigador is not None


class Excursion:
    def __init__(self, codigo: str, dia: str, hora: str) -> None:
        self.codigo = codigo
        self.dia = dia
        self.hora = hora
        self._inscriptos: set[Visitante] = set()

    def inscribir(self, v: Visitante) -> None:
        self._inscriptos.add(v)

    @property
    def inscriptos(self) -> set[Visitante]:
        return set(self._inscriptos)


class Alojamiento:
    def __init__(self, nombre: str, capacidad: int, categoria: str) -> None:
        self.nombre = nombre
        self.capacidad = capacidad
        self.categoria = categoria
        self._organiza: set[Excursion] = set()

    def organizar(self, e: Excursion) -> None:
        self._organiza.add(e)

    @property
    def organiza(self) -> set[Excursion]:
        return set(self._organiza)


# ── Clases asociación ──
@dataclass(frozen=True)
class IndividuosPorArea:
    """CLASE ASOCIACIÓN (Area, Especie): cantidad_individuos."""
    area: Area
    especie: Especie
    cantidad_individuos: int


@dataclass(frozen=True)
class Estancia:
    """CLASE ASOCIACIÓN (Visitante, Alojamiento)."""
    visitante: Visitante
    alojamiento: Alojamiento
    habitacion: str
    fecha_inicio: date
    fecha_fin: date


class Investigacion:
    """CLASE ASOCIACIÓN TERNARIA (Personal-investigador, Proyecto, Especie[])."""
    def __init__(self, investigador: Personal, proyecto: Proyecto) -> None:
        if not investigador.es_investigador:
            raise ValueError("El personal debe tener rol Investigador")
        self.investigador = investigador
        self.proyecto = proyecto
        self._especies: set[Especie] = set()

    def agregar_especie(self, e: Especie) -> None:
        self._especies.add(e)

    @property
    def especies_investigadas(self) -> set[Especie]:
        return set(self._especies)


class Parque:
    def __init__(self, nombre: str, fecha_declaracion: str) -> None:
        self.nombre = nombre
        self.fecha_declaracion_pn = fecha_declaracion
        self._areas: list[Area] = []
        self._entradas: list[Entrada] = []
        self._alojamientos: list[Alojamiento] = []
        self._se_extiende_por: set[ComunidadAutonoma] = set()

    def agregar_area(self, a: Area) -> None:
        if any(x.nombre == a.nombre for x in self._areas):
            raise ValueError("No hay dos areas del mismo parque con igual nombre")
        self._areas.append(a)

    def agregar_entrada(self, e: Entrada) -> None:
        self._entradas.append(e)

    def agregar_alojamiento(self, al: Alojamiento) -> None:
        if any(x.nombre == al.nombre for x in self._alojamientos):
            raise ValueError("No hay dos alojamientos del mismo parque con igual nombre")
        self._alojamientos.append(al)

    def extender_por(self, ca: ComunidadAutonoma) -> None:
        self._se_extiende_por.add(ca)

    @property
    def areas(self) -> list[Area]: return list(self._areas)
    @property
    def entradas(self) -> list[Entrada]: return list(self._entradas)
    @property
    def alojamientos(self) -> list[Alojamiento]: return list(self._alojamientos)
    @property
    def se_extiende_por(self) -> set[ComunidadAutonoma]: return set(self._se_extiende_por)
