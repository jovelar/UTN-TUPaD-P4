from datetime import date
from parques import (Vegetal, Herbivora, Carnivora, Especie, Animal, ComunidadAutonoma,
                     Vehiculo, Entrada, Area, Proyecto, Visitante, Personal, Excursion,
                     Alojamiento, IndividuosPorArea, Estancia, Investigacion, Parque)
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def main():
    print("=== Ejercicio 6: Parques nacionales ===\n")
    roble = Vegetal("Quercus", "Roble", True, "Primavera")
    ciervo = Herbivora("Cervus", "Ciervo", "Otono")
    lobo = Carnivora("Canis lupus", "Lobo", "Invierno")
    check("Roble es Vegetal es Especie", isinstance(roble, Vegetal) and isinstance(roble, Especie))
    check("Ciervo es Herbivora es Animal", isinstance(ciervo, Herbivora) and isinstance(ciervo, Animal))
    check("Lobo dieta = Carnivora", lobo.dieta() == "Carnivora")
    ciervo.agregar_alimento(roble); lobo.agregar_alimento(ciervo)
    check("Ciervo se alimenta de Roble", roble in ciervo.se_alimenta_de)
    check("Lobo se alimenta de Ciervo", ciervo in lobo.se_alimenta_de)
    parque = Parque("Aiguestortes", "1955-10-21")
    bosque = Area("Bosque Norte", 12.5)
    parque.agregar_area(bosque); parque.agregar_entrada(Entrada(1))
    check("Parque 1 area y 1 entrada", len(parque.areas) == 1 and len(parque.entradas) == 1)
    try:
        parque.agregar_area(Area("Bosque Norte", 3)); r = False
    except ValueError: r = True
    check("Rechaza areas con igual nombre", r)
    parque.extender_por(ComunidadAutonoma("Cataluna", "Generalitat"))
    check("Parque se extiende por 1 CA", len(parque.se_extiende_por) == 1)
    juan = Personal("111", "Juan", "Calle 1", "555", 2000, "SS-1")
    juan.asignar_trabajo(parque)
    e1 = Entrada(2); parque.agregar_entrada(e1)
    juan.como_celador().asignar_entrada(e1)
    juan.como_guarda().asignar(bosque, Vehiculo("4x4", "ABC123"))
    juan.como_investigador("Biologo")
    check("Juan es celador Y guarda Y investigador (overlapping)",
          juan.es_celador and juan.es_guarda and juan.es_investigador)
    check("Rol celador en entrada", juan.como_celador().entrada_destino is e1)
    check("Rol guarda con area", juan.como_guarda().area_asignada is bosque)
    ipa = IndividuosPorArea(bosque, ciervo, 40)
    check("IndividuosPorArea liga Area+Especie", ipa.cantidad_individuos == 40)
    refugio = Alojamiento("Refugio Alto", 30, "Rustico")
    parque.agregar_alojamiento(refugio)
    exc = Excursion("EX-1", "Sabado", "09:00"); refugio.organizar(exc)
    v = Visitante("999", "Marta", "Dir", "Docente"); exc.inscribir(v)
    check("Alojamiento organiza excursion", exc in refugio.organiza)
    check("Visitante inscripto", v in exc.inscriptos)
    est = Estancia(v, refugio, "Hab-3", date.today(), date.today())
    check("Estancia liga visitante y alojamiento", est.habitacion == "Hab-3")
    proy = Proyecto("Fauna 2026", 50000, date.today(), date.today())
    inv = Investigacion(juan, proy); inv.agregar_especie(lobo); inv.agregar_especie(ciervo)
    check("Investigacion ternaria liga investigador+proyecto", inv.investigador is juan and inv.proyecto is proy)
    check("Investigacion registra especies", len(inv.especies_investigadas) == 2)
    no_inv = Personal("222", "Pedro", "d", "t", 1500, "SS-2")
    try:
        Investigacion(no_inv, proy); r = False
    except ValueError: r = True
    check("No se investiga sin rol Investigador", r)
    print(f"\n=== Resultado Ej.6: {_o}/{_c} verificaciones OK ===")
main()
