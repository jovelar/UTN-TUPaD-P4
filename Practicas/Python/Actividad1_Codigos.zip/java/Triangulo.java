// ACTIVIDAD 1 · Version CORRECTA en Java
//
// Si el desarrollador escribe mal el nombre del metodo (p.ej. "calcularAera")
// y tiene @Override puesto, el compilador tira el siguiente error y detiene
// la compilacion:
//
//   error: method does not override or implement a method from a supertype
//
// Por eso en Java el typo silencioso de la version Python (ver
// python/typo_silencioso.py) es imposible: el compilador lo hace explotar
// en el momento de compilar, no en produccion.

public class Triangulo extends Poligono {

    private final double base;
    private final double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return base * altura / 2;
    }

    public static void main(String[] args) {
        Triangulo t = new Triangulo(4, 6);
        System.out.println("Area: " + t.calcularArea()); // Area: 12.0
    }
}
