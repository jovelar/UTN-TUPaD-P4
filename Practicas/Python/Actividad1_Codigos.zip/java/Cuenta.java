// ACTIVIDAD 1 · Inversion 1: de la imposicion al acuerdo
//
// En Java, "private" es una barrera que hace cumplir el COMPILADOR.
// Si otra clase (fuera de este archivo/paquete) intenta acceder a "saldo"
// directamente, el programa NO COMPILA. No es una sugerencia, es una regla
// mecanica que el lenguaje impone sin negociar.

public class Cuenta {

    private int saldo; // <- nadie fuera de esta clase puede tocar esto directo

    public Cuenta(int saldoInicial) {
        this.saldo = saldoInicial;
    }

    public int getSaldo() {
        return saldo;
    }

    public static void main(String[] args) {
        Cuenta cuenta = new Cuenta(1000);
        System.out.println("Saldo: " + cuenta.getSaldo());

        // La siguiente linea, si se descomenta, NO COMPILA:
        // cuenta.saldo = 999;
        // error: saldo has private access in Cuenta
    }
}
