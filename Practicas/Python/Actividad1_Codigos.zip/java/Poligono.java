// ACTIVIDAD 1 · El @Override que SI protege (contraparte de typo_silencioso.py)
//
// En Java, la anotacion @Override le pide al COMPILADOR que verifique que
// este metodo realmente sobrescribe algo de la clase padre. Si el nombre o
// la firma no coinciden con ningun metodo del padre, el codigo NO COMPILA.

public abstract class Poligono {
    public abstract double calcularArea();
}
