"""
ACTIVIDAD 1 - La red que Python 3.12 agrega: @typing.override

@override no hace NADA en tiempo de ejecucion (el interprete lo ignora
igual que cualquier otro decorador informativo). Pero le da a la
herramienta de analisis estatico MYPY la informacion necesaria para
detectar el typo ANTES de ejecutar el programa -algo parecido a lo que
hace @Override en Java, pero opcional: hay que acordarse de ponerlo y
de correr mypy.

Correr:  mypy --strict typo_con_override.py
mypy deberia marcar un error en la linea de "calcular_aera" porque no
sobrescribe ningun metodo de Poligono.
"""

from typing import override


class Poligono:
    def calcular_area(self) -> float:
        raise NotImplementedError


class Triangulo(Poligono):
    def __init__(self, base: float, altura: float) -> None:
        self.base = base
        self.altura = altura

    @override
    def calcular_aera(self) -> float:  # mypy: error, no sobrescribe nada
        return self.base * self.altura / 2
