"""
ACTIVIDAD 1 - El typo silencioso (ejemplo central de la actividad)

En Java, @Override obliga al compilador a verificar que el metodo realmente
sobrescribe algo del padre (ver java/Triangulo.java). En Python NO existe
ningun mecanismo equivalente por defecto: si escribis mal el nombre de un
metodo que queres sobrescribir, Python simplemente crea un metodo NUEVO.
No hay error. No hay warning. El bug es completamente silencioso.
"""


class Poligono:
    def calcular_area(self) -> float:
        raise NotImplementedError


class Triangulo(Poligono):
    def __init__(self, base: float, altura: float) -> None:
        self.base = base
        self.altura = altura

    # TYPO: deberia llamarse "calcular_area", no "calcular_aera".
    # Python no avisa: esto es un metodo NUEVO, no una sobrescritura.
    def calcular_aera(self) -> float:
        return self.base * self.altura / 2


if __name__ == "__main__":
    t = Triangulo(4, 6)

    # Esto NO llama al metodo de Triangulo (por el typo).
    # Llama al de Poligono, que explota con NotImplementedError.
    try:
        print("Area:", t.calcular_area())
    except NotImplementedError:
        print("BUG SILENCIOSO: calcular_area() nunca fue sobrescrito.")

    # El metodo "nuevo" SI existe y funciona, pero nadie lo esta llamando:
    print("El metodo con el typo funciona solo:", t.calcular_aera())
