"""
ACTIVIDAD 1 - Inversion 1: de la imposicion al acuerdo

En Python, el guion bajo (_saldo) es SOLO una convencion. Es un cartel que
dice "esto es interno, no lo toques". El interprete no hace absolutamente
nada para impedir el acceso: los linters lo marcan, los IDEs lo esconden del
autocompletado, la comunidad lo respeta -pero el codigo de abajo compila
y corre sin ningun error.

La decision de diseno (que es interno y que es publico) es identica a la de
Java. Lo que cambia es QUIEN la hace cumplir: en Java, el compilador.
En Python, el equipo (convencion + linter + code review).
"""


class Cuenta:
    def __init__(self, saldo_inicial: int) -> None:
        self._saldo = saldo_inicial  # convencion: "no tocar desde afuera"

    @property
    def saldo(self) -> int:
        return self._saldo


if __name__ == "__main__":
    cuenta = Cuenta(1000)
    print("Saldo:", cuenta.saldo)

    # Esto NO deberia hacerse (rompe la convencion), pero Python lo permite
    # sin ningun error, a diferencia de Java:
    cuenta._saldo = 999
    print("Saldo despues del acceso indebido:", cuenta.saldo)
