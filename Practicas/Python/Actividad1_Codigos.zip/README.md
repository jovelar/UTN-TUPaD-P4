# Actividad 1 — El cambio de mentalidad y la tabla maestra

## java/
- Cuenta.java — private como barrera del compilador
- Poligono.java / Triangulo.java — @Override correcto (contraparte del typo)

## python/
- cuenta.py — el guion bajo como convencion, no como barrera
- typo_silencioso.py — el bug central de la actividad: un typo crea un metodo nuevo
- typo_con_override.py — la red opcional de Python 3.12 (@typing.override + mypy)
