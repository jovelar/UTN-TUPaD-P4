from datetime import date
from aerodromo import (TipoAvion, Hangar, PersonaSimple, Piloto, Mecanico, Avion, Persona, Propiedad)
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def main():
    print("=== Ejercicio 8: Aerodromo ===\n")
    b737 = TipoAvion("B737", 180, 41000)
    lvabc = Avion("LV-ABC", b737); lvxyz = Avion("LV-XYZ", b737)
    check("Dos aviones comparten TipoAvion", lvabc.tipo is lvxyz.tipo)
    check("El peso vive en el tipo", lvabc.tipo.peso == 41000)
    h1 = Hangar(1, 5, "Norte"); lvabc.guardar_en(h1)
    check("Avion se guarda en hangar", lvabc.hangar is h1)
    d1 = PersonaSimple("SS1", "Carlos", "d", "t")
    piloto = Piloto("SS2", "Laura", "d", "t", "LIC-9", "ninguna")
    mec = Mecanico("SS3", "Jose", "d", "t", 3000, "Manana")
    check("Piloto es Persona", isinstance(piloto, Persona))
    check("Mecanico es Persona", isinstance(mec, Persona))
    check("PersonaSimple es Persona (incomplete)", isinstance(d1, Persona))
    piloto.autorizar_vuelo(b737); mec.habilitar_mantenimiento(b737)
    check("Piloto autorizado a un TIPO", b737 in piloto.autorizado_a_volar)
    check("Mecanico habilitado a un TIPO", b737 in mec.puede_mantener)
    lvabc.registrar_propiedad(d1, date(2020, 1, 1))
    check("Propietario actual es Carlos", lvabc.propietario_actual() is d1)
    d2 = PersonaSimple("SS4", "Ana", "d", "t")
    lvabc.registrar_propiedad(d2, date(2023, 6, 1))
    check("Propietario actual ahora es Ana", lvabc.propietario_actual() is d2)
    check("Historial conserva 2 propiedades", len(lvabc.propiedades) == 2)
    check("Solo 1 propiedad vigente", sum(1 for p in lvabc.propiedades if p.es_actual) == 1)
    hoy = date(2026, 7, 4)
    lvabc.registrar_servicio(mec, hoy, 2.0, "Motor")
    lvabc.registrar_servicio(mec, hoy, 1.5, "Tren")
    check("Dos servicios mismo avion/fecha, distinto trabajo: OK", len(lvabc.servicios) == 2)
    try:
        lvabc.registrar_servicio(mec, hoy, 3.0, "Motor"); r = False
    except ValueError: r = True
    check("Rechaza servicio duplicado", r)
    from datetime import timedelta
    lvabc.registrar_servicio(mec, hoy + timedelta(days=1), 2.0, "Motor")
    check("Mismo trabajo otra fecha: OK", len(lvabc.servicios) == 3)
    print(f"\n=== Resultado Ej.8: {_o}/{_c} verificaciones OK ===")
main()
