"""Ej.8 — Aeródromo. Dos clases asociación con distinta cardinalidad; tipo/instancia."""
from __future__ import annotations
from abc import ABC
from dataclasses import dataclass
from datetime import date


class Persona(ABC):
    """Jerarquía {disjoint, incomplete}: Mecanico / Piloto / Persona simple."""
    def __init__(self, nss: str, nombre: str, direccion: str, telefono: str) -> None:
        self.nss = nss
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono


class PersonaSimple(Persona):
    """Persona sin especialización (puede ser propietario: {incomplete})."""


@dataclass(frozen=True)
class TipoAvion:
    """Clasificador: datos compartidos por todos los aviones del modelo (tipo/instancia)."""
    nro_modelo: str
    capacidad: float
    peso: float


@dataclass(frozen=True)
class Hangar:
    numero: int
    capacidad: int
    ubicacion: str


class Piloto(Persona):
    def __init__(self, nss, nombre, direccion, telefono, nro_licencia, restricciones) -> None:
        super().__init__(nss, nombre, direccion, telefono)
        self.nro_licencia = nro_licencia
        self.restricciones = restricciones
        self._autorizado: set[TipoAvion] = set()

    def autorizar_vuelo(self, t: TipoAvion) -> None:
        self._autorizado.add(t)

    @property
    def autorizado_a_volar(self) -> set[TipoAvion]:
        return set(self._autorizado)


class Mecanico(Persona):
    def __init__(self, nss, nombre, direccion, telefono, salario, turno) -> None:
        super().__init__(nss, nombre, direccion, telefono)
        self.salario = salario
        self.turno = turno
        self._puede_mantener: set[TipoAvion] = set()

    def habilitar_mantenimiento(self, t: TipoAvion) -> None:
        self._puede_mantener.add(t)

    @property
    def puede_mantener(self) -> set[TipoAvion]:
        return set(self._puede_mantener)


class Propiedad:
    """CLASE ASOCIACIÓN (Avion, Persona): UNA por par. fecha_baja=None => propietario actual."""
    def __init__(self, avion: "Avion", propietario: Persona, fecha_adq: date) -> None:
        self.avion = avion
        self.propietario = propietario
        self.fecha_adquisicion = fecha_adq
        self.fecha_baja: date | None = None

    @property
    def es_actual(self) -> bool:
        return self.fecha_baja is None

    def dar_de_baja(self, fecha: date) -> None:
        self.fecha_baja = fecha


class Servicio:
    """CLASE ASOCIACIÓN (Mecanico, Avion): VARIAS por par. Unicidad {avion, fecha, tipo_trabajo}."""
    def __init__(self, mecanico: Mecanico, avion: "Avion", fecha: date,
                 horas: float, tipo_trabajo: str) -> None:
        self.mecanico = mecanico
        self.avion = avion
        self.fecha = fecha
        self.horas = horas
        self.tipo_trabajo = tipo_trabajo

    def misma_clave(self, otro: "Servicio") -> bool:
        return (self.avion is otro.avion and self.fecha == otro.fecha
                and self.tipo_trabajo == otro.tipo_trabajo)


class Avion:
    """* -- 1 TipoAvion; * -- 1 Hangar. Gestiona Propiedades (historial) y Servicios (unicidad)."""
    def __init__(self, matricula: str, tipo: TipoAvion) -> None:
        self.matricula = matricula
        self.tipo = tipo
        self.hangar: Hangar | None = None
        self._propiedades: list[Propiedad] = []
        self._servicios: list[Servicio] = []

    def guardar_en(self, h: Hangar) -> None:
        self.hangar = h

    def registrar_propiedad(self, nuevo: Persona, fecha: date) -> Propiedad:
        for p in self._propiedades:
            if p.es_actual:
                p.dar_de_baja(fecha)
        prop = Propiedad(self, nuevo, fecha)
        self._propiedades.append(prop)
        return prop

    @property
    def propiedades(self) -> list[Propiedad]:
        return list(self._propiedades)

    def propietario_actual(self) -> Persona | None:
        for p in self._propiedades:
            if p.es_actual:
                return p.propietario
        return None

    def registrar_servicio(self, m: Mecanico, fecha: date, horas: float, tipo_trabajo: str) -> Servicio:
        nuevo = Servicio(m, self, fecha, horas, tipo_trabajo)
        for s in self._servicios:
            if s.misma_clave(nuevo):
                raise ValueError("Ya existe un servicio {avion,fecha,tipo_trabajo} igual")
        self._servicios.append(nuevo)
        return nuevo

    @property
    def servicios(self) -> list[Servicio]:
        return list(self._servicios)
