"""Ej.2 — Países, provincias y ciudades. Reflexivas y rol de asociación."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class Continente:
    nombre: str


@dataclass(frozen=True)
class Ciudad:
    nombre: str


class Provincia:
    """Composición 1 *-- 1..* Ciudad; rol capital; reflexiva {mismo país}; limita con países."""
    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self.pais: Pais | None = None
        self._ciudades: list[Ciudad] = []
        self._capital: Ciudad | None = None
        self._limitrofes: set[Provincia] = set()
        self._limitrofes_paises: set[Pais] = set()

    def agregar_ciudad(self, c: Ciudad) -> None:
        self._ciudades.append(c)

    @property
    def ciudades(self) -> list[Ciudad]:
        return list(self._ciudades)

    @property
    def capital(self) -> Ciudad | None:
        return self._capital

    @capital.setter
    def capital(self, c: Ciudad) -> None:
        if c not in self._ciudades:
            raise ValueError("La capital debe ser una ciudad de la provincia")
        self._capital = c

    def limitar_con(self, otra: "Provincia") -> None:
        if otra is self:
            raise ValueError("Una provincia no limita consigo misma")
        if self.pais is not None and otra.pais is not None and self.pais is not otra.pais:
            raise ValueError("Restriccion {mismo pais}")
        self._limitrofes.add(otra)
        otra._limitrofes.add(self)

    @property
    def limitrofes(self) -> set["Provincia"]:
        return set(self._limitrofes)

    def limitar_con_pais(self, p: "Pais") -> None:
        self._limitrofes_paises.add(p)

    @property
    def limitrofes_paises(self) -> set["Pais"]:
        return set(self._limitrofes_paises)


class Pais:
    """Composición 1 *-- 1..* Provincia; rol capital; reflexiva; se localiza en Continente."""
    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self._provincias: list[Provincia] = []
        self.capital: Ciudad | None = None
        self._limitrofes: set[Pais] = set()
        self.continente: Continente | None = None

    def agregar_provincia(self, p: Provincia) -> None:
        self._provincias.append(p)
        p.pais = self

    @property
    def provincias(self) -> list[Provincia]:
        return list(self._provincias)

    def limitar_con(self, otro: "Pais") -> None:
        if otro is self:
            raise ValueError("Un pais no limita consigo mismo")
        self._limitrofes.add(otro)
        otro._limitrofes.add(self)

    @property
    def limitrofes(self) -> set["Pais"]:
        return set(self._limitrofes)
