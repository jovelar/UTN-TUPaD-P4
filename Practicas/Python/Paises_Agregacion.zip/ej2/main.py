from paises import Continente, Ciudad, Provincia, Pais
_checks = _ok = 0
def check(d, c):
    global _checks, _ok
    _checks += 1
    print(f"  [{'OK' if c else 'FALLA'}] {d}"); _ok += 1 if c else 0

def main():
    print("=== Ejercicio 2: Paises, provincias y ciudades ===\n")
    sudamerica = Continente("Sudamerica")
    arg = Pais("Argentina"); arg.continente = sudamerica
    mendoza, sanjuan = Provincia("Mendoza"), Provincia("San Juan")
    arg.agregar_provincia(mendoza); arg.agregar_provincia(sanjuan)
    check("Argentina tiene 2 provincias", len(arg.provincias) == 2)
    check("Provincia conoce su pais", mendoza.pais is arg)
    check("Pais localizado en continente", arg.continente is sudamerica)

    ciudad_mza, godoy = Ciudad("Ciudad de Mendoza"), Ciudad("Godoy Cruz")
    mendoza.agregar_ciudad(ciudad_mza); mendoza.agregar_ciudad(godoy)
    mendoza.capital = ciudad_mza
    check("Capital de provincia es una de sus ciudades", mendoza.capital is ciudad_mza)
    try:
        mendoza.capital = Ciudad("Ajena"); r = False
    except ValueError:
        r = True
    check("No se puede poner capital una ciudad ajena", r)

    caba = Ciudad("Buenos Aires"); arg.capital = caba
    check("Pais tiene capital (rol asociacion)", arg.capital is caba)

    mendoza.limitar_con(sanjuan)
    check("Mendoza limita con San Juan (reflexiva)", sanjuan in mendoza.limitrofes)
    check("Reflexiva bidireccional", mendoza in sanjuan.limitrofes)

    chile = Pais("Chile"); coquimbo = Provincia("Coquimbo"); chile.agregar_provincia(coquimbo)
    try:
        mendoza.limitar_con(coquimbo); r = False
    except ValueError:
        r = True
    check("Restriccion {mismo pais}", r)
    mendoza.limitar_con_pais(chile)
    check("Mendoza limita con el pais Chile", chile in mendoza.limitrofes_paises)
    arg.limitar_con(chile)
    check("Argentina limita con Chile", chile in arg.limitrofes)
    check("Bidireccional pais-pais", arg in chile.limitrofes)
    print(f"\n=== Resultado Ej.2: {_ok}/{_checks} verificaciones OK ===")

main()
