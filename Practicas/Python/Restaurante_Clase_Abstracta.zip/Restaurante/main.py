from restaurantes import Sucursal, Plato, PlatoServido, Restaurante, Persona
_c = _o = 0
def check(d, c):
    global _c, _o; _c += 1; _o += 1 if c else 0
    print(f"  [{'OK' if c else 'FALLA'}] {d}")
def main():
    print("=== Ejercicio 5: Restaurantes ===\n")
    don_pepe = Restaurante("Don Pepe"); la_parrilla = Restaurante("La Parrilla")
    don_pepe.agregar_sucursal(Sucursal("San Martin 100"))
    don_pepe.agregar_sucursal(Sucursal("Belgrano 500"))
    check("Don Pepe tiene 2 sucursales", len(don_pepe.sucursales) == 2)
    milanesa = Plato("Milanesa")
    mila_dp = don_pepe.ofrecer_plato(milanesa, 9)
    mila_lp = la_parrilla.ofrecer_plato(milanesa, 4)
    check("Misma milanesa, dos PlatoServido distintos", mila_dp is not mila_lp)
    check("PlatoServido conoce su plato", mila_dp.plato is milanesa)
    check("PlatoServido conoce su restaurante", mila_dp.restaurante is don_pepe)
    ana = Persona("Ana"); ana.frecuentar(don_pepe); ana.frecuentar(la_parrilla)
    ana.gustar(mila_dp)
    check("A Ana le gusta la milanesa EN Don Pepe", mila_dp in ana.le_gusta)
    check("A Ana NO le gusta la milanesa EN La Parrilla", mila_lp not in ana.le_gusta)
    check("El modelo distingue el gusto por restaurante", len(ana.le_gusta) == 1 and len(ana.frecuenta) == 2)
    flan = Plato("Flan"); flan_srv = don_pepe.ofrecer_plato(flan, 5)
    check("Flan servido existe sin gustarle a nadie", flan_srv in don_pepe.menu)
    check("Ana frecuenta 2 restaurantes", len(ana.frecuenta) == 2)
    grande = Restaurante("Buffet")
    for i in range(20): grande.ofrecer_plato(Plato(f"P{i}"), 5)
    check("Buffet ofrece 20 platos", len(grande.menu) == 20)
    try:
        grande.ofrecer_plato(Plato("P21"), 5); r = False
    except ValueError: r = True
    check("No se puede ofrecer plato 21 (0..20)", r)
    mila_lp.valoracion = 6
    check("valoracion vive en el PlatoServido", mila_lp.valoracion == 6)
    check("Independiente de la del otro restaurante", mila_dp.valoracion == 9)
    print(f"\n=== Resultado Ej.5: {_o}/{_c} verificaciones OK ===")
main()
