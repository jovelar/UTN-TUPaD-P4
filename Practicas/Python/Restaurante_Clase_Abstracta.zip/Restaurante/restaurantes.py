"""Ej.5 — Restaurantes. Clase asociación PlatoServido."""
from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Sucursal:
    direccion: str


@dataclass(frozen=True)
class Plato:
    nombre: str


class PlatoServido:
    """CLASE ASOCIACIÓN: reifica 'Restaurante ofrece Plato'. El gusto depende de la combinación."""
    def __init__(self, restaurante: "Restaurante", plato: Plato, valoracion: int) -> None:
        self.restaurante = restaurante
        self.plato = plato
        self.valoracion = valoracion            # atributo propio de la combinación

    def __repr__(self) -> str:
        return f"{self.plato.nombre}@{self.restaurante.nombre}(val={self.valoracion})"


class Restaurante:
    """Composición 1 *-- * Sucursal. Ofrece hasta 20 platos reificados como PlatoServido."""
    MAX_PLATOS = 20

    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self._sucursales: list[Sucursal] = []
        self._menu: list[PlatoServido] = []

    def agregar_sucursal(self, s: Sucursal) -> None:
        self._sucursales.append(s)

    @property
    def sucursales(self) -> list[Sucursal]:
        return list(self._sucursales)

    def ofrecer_plato(self, p: Plato, valoracion_inicial: int) -> PlatoServido:
        if len(self._menu) >= self.MAX_PLATOS:
            raise ValueError("Un restaurante no ofrece mas de 20 platos")
        ps = PlatoServido(self, p, valoracion_inicial)
        self._menu.append(ps)
        return ps

    @property
    def menu(self) -> list[PlatoServido]:
        return list(self._menu)


class Persona:
    """Asociaciones * -- * Restaurante (frecuenta) y * -- * PlatoServido (le gusta)."""
    def __init__(self, nombre: str) -> None:
        self.nombre = nombre
        self._frecuenta: set[Restaurante] = set()
        self._le_gusta: set[PlatoServido] = set()

    def frecuentar(self, r: Restaurante) -> None:
        self._frecuenta.add(r)

    @property
    def frecuenta(self) -> set[Restaurante]:
        return set(self._frecuenta)

    def gustar(self, ps: PlatoServido) -> None:
        """A la persona le gusta un PLATO SERVIDO, no un plato abstracto."""
        self._le_gusta.add(ps)

    @property
    def le_gusta(self) -> set[PlatoServido]:
        return set(self._le_gusta)
